// util functions for agendamentos to be reused and unit-tested
export const isCompleted = (a) => {
  if (!a) return false;
  try {
    if (a.concluido === true) return true;
    if (a.realizado === true) return true;
    if (a.ativo === false) return true;
    const s = (a.status || a.situacao || a.estado || "").toString().toLowerCase();
    if (!s) return false;
    if (s.includes("concl") || s.includes("finaliz") || s.includes("realiz") || s.includes("fechado") || s.includes("realizado")) return true;
  } catch (e) {
    return false;
  }
  return false;
};

export const filterByStatus = (list, filter) => {
  if (!Array.isArray(list)) return [];
  if (!filter || filter === "Todos") return list;
  if (filter === "Concluídos") return list.filter(isCompleted);
  if (filter === "Pendentes") return list.filter((a) => !isCompleted(a));
  return list;
};
