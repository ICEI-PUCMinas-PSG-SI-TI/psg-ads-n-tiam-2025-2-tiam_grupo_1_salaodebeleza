import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  Modal,
  TextInput,
} from "react-native";
import Header from "../components/Header";
import Card from "../components/Card";
import Button from "../components/Button";
import Filter from "../components/Filter";
import FilterDate from "../components/FilterDate";
import { theme } from "../styles/theme";
import {
  listenAgendamentos,
  deleteAgendamento,
} from "../services/agendamentoService";
import { listenServicos } from "../services/servicoService";
import { listenClientes } from "../services/clienteService";
import { listenFuncionarios } from "../services/funcionarioService";
import { isCompleted, filterByStatus } from "../utils/agendamentoUtils";

export default function Relatorios() {
  const [agendamentos, setAgendamentos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("Todos");
  const [filters, setFilters] = useState({
    date: null,
    cliente: "",
    servico: [],
    profissional: [],
  });

  const [servicosList, setServicosList] = useState([]);
  const [clientesList, setClientesList] = useState([]);
  const [funcionariosList, setFuncionariosList] = useState([]);

  const [modalViewVisible, setModalViewVisible] = useState(false);
  const [agendamentoSelecionado, setAgendamentoSelecionado] = useState(null);

  useEffect(() => {
    setLoading(true);
    const unsubA = listenAgendamentos((lista) => {
      setAgendamentos(lista || []);
      setLoading(false);
    });

    const unsubS = listenServicos((lista) => {
      setServicosList((lista || []).map((s) => ({ id: s.id || s.sid || s.uid || s.nome, nome: s.nome || s })));
    });

    const unsubC = listenClientes((lista) => {
      setClientesList((lista || []).map((c) => ({ id: c.id || c.cid || c.uid || c.nome, nome: c.nome || c })));
    });

    const unsubF = listenFuncionarios((lista) => {
      setFuncionariosList((lista || []).map((f) => ({ id: f.id || f.fid || f.uid || f.nome, nome: f.nome || f })));
    });

    return () => {
      if (typeof unsubA === "function") unsubA();
      if (typeof unsubS === "function") unsubS();
      if (typeof unsubC === "function") unsubC();
      if (typeof unsubF === "function") unsubF();
    };
  }, []);

  const abrirModalView = (agendamento) => {
    setAgendamentoSelecionado(agendamento);
    setModalViewVisible(true);
  };

  const fecharModalView = () => {
    setAgendamentoSelecionado(null);
    setModalViewVisible(false);
  };

  const handleExcluir = async () => {
    if (!agendamentoSelecionado) return;

    Alert.alert(
      "Excluir agendamento",
      `Tem certeza que deseja excluir este agendamento?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            try {
              setLoading(true);
              const result = await deleteAgendamento(agendamentoSelecionado.id || agendamentoSelecionado.uid);
              if (result && result.success) {
                Alert.alert("Sucesso", "Agendamento excluído com sucesso!");
                setAgendamentos((prev) =>
                  prev.filter((a) => (a.id || a.uid) !== (agendamentoSelecionado.id || agendamentoSelecionado.uid))
                );
                fecharModalView();
              } else {
                Alert.alert("Erro", result && result.message ? result.message : "Falha ao excluir agendamento.");
              }
            } catch (error) {
              Alert.alert("Erro", error.message);
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const filteredByStatus = filterByStatus(agendamentos, filter);

  const applyExtraFilters = (list) => {
    let res = list || [];

    if (filters.date) {
      res = res.filter((a) => a.data === filters.date);
    }

    if (filters.cliente && filters.cliente.trim().length > 0) {
      const q = filters.cliente.toLowerCase();
      res = res.filter((a) => {
        const nome =
          (a.cliente && (a.cliente.nome || a.cliente)) || a.clienteNome || "";
        return nome.toString().toLowerCase().includes(q);
      });
    }

    if (filters.servico && filters.servico.length > 0) {
      res = res.filter((a) => {
        const s = a.servicos || a.servico || [];
        const names = Array.isArray(s) ? s.map((x) => (x && (x.nome || x))) : [s && (s.nome || s)];
        return filters.servico.some((f) => names.join(" ").toLowerCase().includes(String(f).toLowerCase()));
      });
    }

    if (filters.profissional && filters.profissional.length > 0) {
      res = res.filter((a) => {
        const p = a.profissionais || a.profissional || [];
        const names = Array.isArray(p) ? p.map((x) => (x && (x.nome || x))) : [p && (p.nome || p)];
        return filters.profissional.some((f) => names.join(" ").toLowerCase().includes(String(f).toLowerCase()));
      });
    }

    return res;
  };

  const filtered = applyExtraFilters(filteredByStatus);

  const groups = filtered.reduce((acc, a) => {
    const key = a.data || "Sem data";
    if (!acc[key]) acc[key] = [];
    acc[key].push(a);
    return acc;
  }, {});

  const sortedDates = Object.keys(groups).sort((d1, d2) => {
    const parseDatePtBr = (dateStr) => {
      if (!dateStr || typeof dateStr !== "string") return null;
      const parts = dateStr.split("/");
      if (parts.length !== 3) return null;
      const [day, month, year] = parts.map((p) => parseInt(p, 10));
      if (Number.isNaN(day) || Number.isNaN(month) || Number.isNaN(year)) return null;
      return new Date(year, month - 1, day);
    };
    const dt1 = parseDatePtBr(d1);
    const dt2 = parseDatePtBr(d2);
    if (!dt1 || !dt2) return d1.localeCompare(d2);
    return dt1.getTime() - dt2.getTime();
  });

  const formatDateHeader = (dateStr) => {
    if (!dateStr) return "Sem data";
    const dt = (() => {
      if (!dateStr || typeof dateStr !== "string") return null;
      const parts = dateStr.split("/");
      if (parts.length !== 3) return null;
      const [day, month, year] = parts.map((p) => parseInt(p, 10));
      if (Number.isNaN(day) || Number.isNaN(month) || Number.isNaN(year)) return null;
      return new Date(year, month - 1, day);
    })();
    if (!dt) return dateStr;
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    dt.setHours(0, 0, 0, 0);
    if (dt.getTime() === hoje.getTime()) {
      return `Hoje - ${dateStr}`;
    }
    return dateStr;
  };

  return (
    <View style={{ flex: 1 }}>
      <Header title="Relatórios" />
      <View style={styles.container}>
        <View style={styles.filtersRow}>
          {["Todos", "Concluídos", "Pendentes"].map((opt) => (
            <Button
              key={opt}
              title={opt}
              onPress={() => setFilter(opt)}
              style={[styles.filterBtn, filter === opt ? styles.filterBtnActive : null]}
              textStyle={filter === opt ? styles.filterTextActive : styles.filterText}
            />
          ))}
        </View>

        <View style={styles.extraFilters}>
          <FilterDate onSelect={(date) => setFilters((prev) => ({ ...prev, date }))} />
          <Filter
            label="Serviços"
            listItem={servicosList.map(s => ({ id: s.id, title: s.nome || s.id }))}
            onSelect={(servicos) => setFilters((prev) => ({ ...prev, servico: servicos || [] }))}
          />
          <Filter
            label="Profissionais"
            listItem={funcionariosList.map(f => ({ id: f.id, title: f.nome || f.id }))}
            onSelect={(profissionais) => setFilters((prev) => ({ ...prev, profissional: profissionais || [] }))}
          />
          <View style={{ flex: 1 }}>
            <TextInput
              placeholder="Pesquisar cliente..."
              value={filters.cliente}
              onChangeText={(t) => setFilters((prev) => ({ ...prev, cliente: t }))}
              style={styles.clientSearch}
            />
          </View>
        </View>

        <View style={{ marginTop: 12, marginBottom: 8 }}>
          <Text style={{ color: theme.colors.text }}>
            Total: {agendamentos.length} • Exibindo: {filtered.length}
          </Text>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color={theme.colors.primary} style={{ marginTop: 20 }} />
        ) : (
          <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
            {sortedDates.length === 0 ? (
              <Text style={{ textAlign: "center", color: theme.colors.textInput, marginTop: 16 }}>
                Nenhum registro encontrado.
              </Text>
            ) : (
              sortedDates.map((dateKey) => {
                const items = (groups[dateKey] || []).sort((a, b) => {
                  const ta = a.horario || a.tempo || "";
                  const tb = b.horario || b.tempo || "";
                  return ta.localeCompare(tb);
                });
                return (
                  <View key={dateKey}>
                    <View style={styles.dateContainer}>
                      <Text style={styles.dateText}>{formatDateHeader(dateKey)}</Text>
                    </View>
                    {items.map((a) => (
                      <Card
                        key={a.uid || a.id}
                        icon="calendar-outline"
                        title={`${(a.cliente && (a.cliente.nome || a.cliente)) || a.clienteNome || a.id} - ${a.horario || "Sem horário"}`}
                        subtitle={`${(a.servicos && Array.isArray(a.servicos) ? a.servicos.map(s => s.nome || s).join(", ") : (a.servico || "-"))} · ${(a.profissionais && Array.isArray(a.profissionais) ? a.profissionais.map(p=>p.nome||p).join(", ") : (a.profissional || "-"))}`}
                        onView={() => abrirModalView(a)}
                        style={styles.card}
                      >
                        <View style={{ marginTop: 6 }}>
                          <Text style={{ color: theme.colors.textInput }}>Data: {a.data || "-"}</Text>
                          <Text style={{ color: theme.colors.textInput }}>Status: {isCompleted(a) ? "Concluído" : "Pendente"}</Text>
                        </View>
                      </Card>
                    ))}
                  </View>
                );
              })
            )}
          </ScrollView>
        )}
      </View>

      <Modal visible={modalViewVisible} animationType="none" transparent={true} onRequestClose={fecharModalView}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeaderRight}>
              <View>
                <Text style={styles.modalTitle}>Detalhes do Agendamento</Text>
                <Text style={styles.modalSubtitle}>Informações rápidas e ações</Text>
              </View>

              <View style={{ flexDirection: "row", gap: 8 }}>
                <Button title="Editar" onPress={() => { /* abrir edição se necessário */ }} />
                <Button title="Fechar" onPress={fecharModalView} />
              </View>
            </View>

            {agendamentoSelecionado && (
              <View style={{ marginTop: 12 }}>
                <View style={{ marginBottom: 12 }}>
                  <Text style={styles.detailLabel}>Cliente</Text>
                  <Text style={styles.detailValue}>{(agendamentoSelecionado.cliente && (agendamentoSelecionado.cliente.nome || agendamentoSelecionado.cliente)) || agendamentoSelecionado.clienteNome || "Não informado"}</Text>
                </View>

                <View style={{ marginBottom: 12 }}>
                  <Text style={styles.detailLabel}>Serviço</Text>
                  <Text style={styles.detailValue}>
                    {(agendamentoSelecionado.servicos && Array.isArray(agendamentoSelecionado.servicos) ? agendamentoSelecionado.servicos.map(s => s.nome||s).join(", ") : (agendamentoSelecionado.servico || "—"))}
                  </Text>
                </View>

                <View style={{ marginBottom: 12 }}>
                  <Text style={styles.detailLabel}>Valor</Text>
                  <Text style={styles.detailValue}>{agendamentoSelecionado.valor ? `R$ ${agendamentoSelecionado.valor}` : "Não informado"}</Text>
                </View>

                <View style={{ marginBottom: 12 }}>
                  <Text style={styles.detailLabel}>Horário</Text>
                  <Text style={styles.detailValue}>{agendamentoSelecionado.horario || "Não informado"}</Text>
                </View>

                <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 12 }}>
                  <Button title="Excluir" onPress={handleExcluir} style={styles.deleteButton} textStyle={styles.deleteButtonText} />
                </View>
              </View>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  filtersRow: {
    flexDirection: "row",
  },
  extraFilters: {
    flexDirection: "row",
    gap: 8,
    marginTop: 10,
    alignItems: "center",
  },
  filterBtn: {
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: 8,
    backgroundColor: theme.colors.surface,
  },
  filterBtnActive: {
    backgroundColor: theme.colors.primary,
  },
  filterText: {
    color: theme.colors.text,
    fontWeight: "600",
  },
  filterTextActive: {
    color: theme.colors.white,
  },
  clientSearch: {
    borderWidth: 1,
    borderColor: theme.colors.surface,
    padding: 8,
    borderRadius: 8,
    minWidth: 140,
  },
  card: {
    marginBottom: 10,
  },
  dateContainer: {
    paddingVertical: 8,
  },
  dateText: {
    fontWeight: "700",
    color: theme.colors.text,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    width: "92%",
    maxHeight: "92%",
    backgroundColor: theme.colors.surface,
    borderRadius: 10,
    padding: 16,
  },
  modalHeaderRight: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: theme.colors.text,
  },
  modalSubtitle: {
    fontSize: 13,
    color: theme.colors.textInput,
  },
  detailLabel: {
    fontSize: 12,
    color: theme.colors.textInput,
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    color: theme.colors.text,
  },

  deleteButton: {
    backgroundColor: theme.colors.primary,
    width: "48%",
    marginTop: 8,
  },
  deleteButtonText: {
    color: theme.colors.white,
    fontWeight: "700",
  },
});
